﻿namespace CrudOperation.VM
{
    public class RoleVM
    {
        public string RoleName { get; set; }
    }
}
