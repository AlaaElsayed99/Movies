﻿namespace CrudOperation.VM
{
    public class AccountDetailsViewModel
    {
        public string Email { get; set; }
        public string Username { get; set; }
        public byte[] Image { get; set; }
        public string Address { get; set; }

    }
}
